// src/components/OverAllDataComponent.tsx
import React, { useEffect, useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { buildOverallStandings, pickStandingTeam } from '../../shared/hooks/officialStandings';

interface Tournament {
  _id: string;
  tournamentName: string;
  torLogo?: string;
  day?: string;
  primaryColor?: string;
  secondaryColor?: string;
  overlayBg?: string;
}

interface Round {
  _id: string;
  roundName: string;
  day?: string;
}

interface Player {
  _id: string;
  uId: string; // Unique identifier for player (e.g., "player1", "player2")
  picUrl?: string;
  playerName: string;
  killNum: number;
}

interface Team {
  teamId: string;
  teamName: string;
  teamTag: string;
  teamLogo: string;
  slot: number;
  placePoints: number;
  wwcd?: number;
  players: Player[];
  totalKills?: number;
  total?: number;
  rank?: number;
  pointsChange?: number;
  leadOverNext?: number;
}

interface OverallData {
  tournamentId: string;
  roundId: string;
  userId: string;
  teams: Team[];
  createdAt: string;
}

interface MatchData {
  _id: string;
  teams: Team[];
}

interface OverAllDataProps {
  tournament: Tournament;
  round?: Round | null;
  overallData?: OverallData | null;
  matchDatas?: MatchData[];
}

const OverAllDataComponent: React.FC<OverAllDataProps> = ({
  tournament,
  round,
  overallData: propOverallData,
  matchDatas: propMatchDatas,
}) => {
  const matchDatas = propMatchDatas || [];
  const [currentPage, setCurrentPage] = useState(0);
  const teamsPerPage = 8;

  // One shared standings pipeline (Total Score primary + real rankChange
  // from match history, else the overallData snapshot). Rows carry
  // rank / matchesPlayed / leadOverNext plus placePoints|total|wwcd aliases.
  const teams = useMemo(
    () => buildOverallStandings(matchDatas as any, propOverallData as any),
    [matchDatas, propOverallData]
  );
  // rank-1 team with roster re-attached, for the hero card.
  const champion = useMemo(
    () => pickStandingTeam(matchDatas as any, propOverallData as any, 0),
    [matchDatas, propOverallData]
  );

  const totalPages = Math.max(1, Math.ceil(teams.length / teamsPerPage));

  useEffect(() => {
    if (totalPages <= 1) return;
    const interval = setInterval(() => {
      setCurrentPage((prev) => (prev + 1) % totalPages);
    }, 25000);
    return () => clearInterval(interval);
  }, [totalPages]);

  const paginatedTeams = useMemo(() => {
    const start = currentPage * teamsPerPage;
    return teams.slice(start, start + teamsPerPage);
  }, [teams, currentPage]);

  if (teams.length === 0) return <div>No data available</div>;

  // ✅ JSX unchanged
  return (
    <div className="w-[1920px] h-[1080px] text-white p-8 ">
      {/* TITLE */}
      <div className="w-full h-[30%]">
        <div className="px-6 py-2 font-[Awaking] tracking-wide text-[160px] absolute top-[30px] left-[190px] font-[700] bg-gradient-to-l from-[#ffa300] to-[#f9df67] text-transparent bg-clip-text scale-y-[1.4]">
          OVERALL STANDINGS
        </div>

        <div
          style={{
            backgroundImage: `linear-gradient(to left, transparent, ${tournament.primaryColor})`,
            clipPath: 'polygon(30px 0%, 100% 0%, 100% 100%, 30px 100%, 0% 50%)',
          }}
          className="w-[1000px] h-[50px] absolute left-[200px] top-[280px] text-white font-[AGENCYB] text-[2.5rem]"
        >
          <div className="relative top-[-5px] left-[50px]">
            {tournament.tournamentName} - {round?.roundName}
          </div>
        </div>
      </div>

      {/* HEADER */}
      <div className="flex">
        {[0, 1].map((col) => (
          <div
            key={col}
            className={`w-[850px] text-black text-[1.8rem] bg-white h-[40px] relative mb-[0px] font-[Agencyb] pl-[30PX] font-[900] top-[300px] ${
              col === 1 ? 'left-[60px]' : 'left-[30px]'
            }`}
          >
            <div className="absolute top-[-1px] w-[800px] flex gap-[80px]">
              <div>#</div>
              <div className="">TEAM</div>
              <div className="ml-[110px]">WWCD</div>
              <div className="ml-[-10px]">PLACE</div>
              <div className="ml-[-5px]">KILLS</div>
              <div className="ml-[-7px]">TOTAL</div>
            </div>
          </div>
        ))}
      </div>

      {/* TOP TEAM */}
      {champion && (
        <div
          style={{
            background: `linear-gradient(90deg, ${tournament.primaryColor} 0%, #000000 50%, ${tournament.secondaryColor} 100%)`,
          }}
          className="grid grid-cols-7 bg-[#000000c1] w-[1730px] h-[240px] ml-[30px] mt-[10px] mb-[60px]"
        >
          <div className="font-[AGENCYB] text-[60px] relative left-[30px] top-[20px]">
            #1
          </div>
       <div className="flex relative top-[-26px] left-[0px]">
  {champion.players
    // Filter to keep only the first occurrence of each unique uId
    .filter((player: any, index: number, self: any[]) => {
      return index === self.findIndex((p: any) => p.uId === player.uId);
    })
    // Sort by kills descending
    .sort((a: any, b: any) => b.killNum - a.killNum)
    // Take top 4 unique uId players
    .slice(0, 4)
    .map((player, idx) => (
      <img
        key={idx}
        src={player.picUrl || '/def_char.png'}
        className="w-[500px] h-[266px] object-cover ml-[-80px] relative left-[-60px]"
      />
    ))}
</div>
          <div className="flex relative top-[-86px] left-[0px]">
            <div className="text-[55px] absolute left-[490px] top-[190px] font-[AGENCYB]">
              {champion.teamTag}
            </div>

            <img
              src={champion.teamLogo}
              className="w-[90px] h-[90px] absolute left-[369px] top-[180px]"
            />
          </div>
          <div className="flex gap-[70px] relative left-[400px] top-[70px] text-center font-[supermolot] font-[900]">
            <div>
              <div className="text-[20px] mb-[-10px]">WWCD</div>
              <div className="text-[70px] font-[Agencyb]">
                {champion.wwcd}
              </div>
            </div>
            <div>
              <div className="text-[20px] mb-[-10px]">PLACE</div>
              <div className="text-[70px] font-[Agencyb]">
                {champion.placePoints}
              </div>
            </div>
            <div>
              <div className="text-[20px] mb-[-10px]">KILLS</div>
              <div className="text-[70px] font-[Agencyb]">
                {champion.totalKills}
              </div>
            </div>
            <div>
              <div className="text-[20px] mb-[-10px]">TOTAL</div>
              <div className="text-[70px] font-[Agencyb]">
                {champion.total}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* LIST */}
      <div className="flex gap-[30px] relative left-[30px] font-[AGENCYB]">
        {/* LEFT COLUMN */}
        <div className="flex flex-col gap-[10px] relative left-[0px]">
          {paginatedTeams.slice(0, 4).map((team, index) => (
            <motion.div
              key={team.teamId}
              className={`w-[850px] h-[80px] flex items-center text-[30px] relative bg-[#000000c1] ${
                team.rank === 1 ? 'border-2 bg-[#400000c1] border-red-500' : ''
              }`}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              {team.rank === 1 && (
                <motion.div
                  className="absolute inset-0 rounded-lg pointer-events-none"
                  initial={{ boxShadow: '0 0 10px rgba(255,0,0,0.5)' }}
                  animate={{
                    boxShadow: [
                      '0 0 10px rgba(255,0,0,0.5)',
                      '0 0 20px rgba(255,0,0,0.8)',
                      '0 0 10px rgba(255,0,0,0.5)',
                    ],
                  }}
                  transition={{ repeat: Infinity, duration: 1.5, ease: 'easeInOut' }}
                />
              )}
              <div className="w-[5%] text-center pl-[20px]">#{team.rank}</div>
              <div className="w-[25%] text-center">{team.teamTag.toUpperCase()}</div>
              <div className="w-[10%] text-center">
                <img src={team.teamLogo} className="w-12 h-12 mx-auto" />
              </div>
              <div className="w-[15%] text-center">{team.wwcd || 0}</div>
              <div className="w-[15%] text-center">{team.placePoints}</div>
              <div className="w-[15%] text-center">{team.totalKills}</div>
              <div className="w-[15%] text-center">{team.total}</div>
            </motion.div>
          ))}
        </div>

        {/* RIGHT COLUMN */}
        <div className="flex flex-col gap-[10px]">
          {paginatedTeams.slice(4, 8).map((team) => {
            const isGlowing = team.rank && team.rank >= 21 && team.rank <= 24;
            return (
              <motion.div
                key={team.teamId}
                className={`w-[850px] h-[80px] flex items-center text-[30px] relative bg-[#000000c1] ${
                  isGlowing ? 'border-2 bg-[#400000c1] border-red-500' : ''
                }`}
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                {isGlowing && (
                  <motion.div
                    className="absolute inset-0 rounded-lg pointer-events-none"
                    initial={{ boxShadow: '0 0 10px rgba(255,0,0,0.5)' }}
                    animate={{
                      boxShadow: [
                        '0 0 10px rgba(255,0,0,0.5)',
                        '0 0 20px rgba(255,0,0,0.8)',
                        '0 0 10px rgba(255,0,0,0.5)',
                      ],
                    }}
                    transition={{ repeat: Infinity, duration: 1.5, ease: 'easeInOut' }}
                  />
                )}
                <div className="w-[5%] text-center pl-[20px]">#{team.rank ?? 0}</div>
                <div className="w-[25%] text-center">{team.teamTag.toUpperCase()}</div>
                <div className="w-[10%] text-center">
                  <img src={team.teamLogo} className="w-12 h-12 mx-auto" />
                </div>
                <div className="w-[15%] text-center">{team.wwcd || 0}</div>
                <div className="w-[15%] text-center">{team.placePoints}</div>
                <div className="w-[15%] text-center">{team.totalKills}</div>
                <div className="w-[15%] text-center">{team.total}</div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default OverAllDataComponent;