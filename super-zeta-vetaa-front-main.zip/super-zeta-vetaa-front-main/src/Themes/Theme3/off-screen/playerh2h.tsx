import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { buildFraggerPool, computeFraggerScores, compareFraggerScore } from '../../shared/hooks/fraggerScore';

interface Tournament {
  _id: string;
  tournamentName: string;
  torLogo?: string;
  day?: string;
  primaryColor?: string;
  secondaryColor?: string;
  overlayBg?: string;
}

interface Round {
  _id: string;
  roundName: string;
  day?: string;
}

interface Match {
  _id: string;
  matchName?: string;
  matchNo?: number;
  _matchNo?: number;
}

interface Player {
  _id: string;
  playerName: string;
  killNum?: number;
  assists?: number;
  knockouts?: number;
  damage?: number;
  headShotNum?: number;
  picUrl?: string;
}

interface Team {
  teamId: string;
  teamName: string;
  teamTag: string;
  teamLogo: string;
  slot: number;
  placePoints: number;
  players: Player[];
}

interface MatchData {
  _id: string;
  matchId: string;
  userId: string;
  teams: Team[];
}

interface PlayerH2HProps {
   tournament: Tournament;
   round?: Round | null;
   match?: Match | null;
   matchData?: MatchData | null;
 }

const PlayerH2H: React.FC<PlayerH2HProps> = ({ tournament, round, match, matchData }) => {
  // Fixed head-to-head pair: rank #1 and #2 by Single-Match Fragger Score
  // (buildFraggerPool([matchData]) degenerates cleanly to per-player raw
  // stats for a single match). latestPlayerRaw is spread back in first so
  // any raw-only fields survive; killNum/damage/assists/knockouts are then
  // remapped from the aggregate fields the JSX below actually reads.
  const topPlayers = useMemo(() => {
    if (!matchData) return null;

    const scored = computeFraggerScores(buildFraggerPool([matchData])).sort(compareFraggerScore);

    const mapPlayer = (p?: typeof scored[number]) => {
      if (!p) return null;
      return {
        ...(p.latestPlayerRaw as any),
        ...p,
        killNum: p.totalKills,
        damage: p.totalDamage,
        assists: p.totalAssists,
        knockouts: p.totalKnockouts,
      };
    };

    return {
      first: mapPlayer(scored[0]),
      second: mapPlayer(scored[1]),
    };
  }, [matchData]);

  if (!matchData || !topPlayers?.first || !topPlayers?.second) {
    return (
      <div style={{ width: '1920px', height: '1080px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ color: 'white', fontSize: '24px', fontFamily: 'Righteous' }}>Not enough players</div>
      </div>
    );
  }

  const { first, second } = topPlayers;

  return (
    <div style={{ width: '1920px', height: '1080px', position: 'relative', color: 'white' }}>
      {/* Header */}
      <motion.div
        className="absolute z-10 top-[60px] text-[5rem] font-bebas font-[300] w-full text-center"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
      >
        <h1 className="text-white font-bold whitespace-pre text-[7rem]">PLAYER HEAD TO HEAD</h1>
        <motion.p
          className="text-white text-[2rem] font-[Righteous] whitespace-pre p-[10px] mt-[-20px] w-[800px] mx-auto mb-[20px] "
          style={{ background: `linear-gradient(45deg, ${tournament.primaryColor || '#000'}, ${tournament.secondaryColor || '#333'})` }}
          animate={{ opacity: [0.9, 1, 0.9] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        >
          {tournament?.tournamentName || '-'} •   {round?.roundName || '-'} • MATCH {match?.matchNo}
        </motion.p>
      </motion.div>

      {/* VS Section */}
      <div className="absolute top-[50%] left-[50%] transform -translate-x-1/2 -translate-y-1/2 flex items-center gap-16">
        {/* Player 1 */}
        <div className="flex flex-col items-center mt-[100px]">
          <div
            style={{
              background: `linear-gradient(135deg, ${tournament.primaryColor || '#000'}, ${tournament.secondaryColor || '#333'})`,
            }}
            className="w-[600px] h-[505px] p-8 flex flex-col items-center justify-center ">
        
           <img
              src={first.picUrl || '/def_char.avif'}
              alt={first.playerName}
              className="w-[300px] h-[300px] object-cover  top-[100px] absolute z-0"
            />
           <div className="text-[3rem] font-bebas text-black px-[20px] flex justify-center bg-gradient-to-r from-[#FFD700] via-[#FFA500] to-[#FFD700] z-10">
              {first.playerName}
            </div>
           
            
            <div className=" w-[600px] text-center bg-[#000000b8] h-[200px] pt-[30px] top-[400px] absolute flex items-center justify-between px-[120px]">
              <div className='w-[100%] text-center'>
                <div className="text-[8rem] font-[AGENCYB] text-yellow-300 ">{first.killNum} KILLS</div>
                
              </div>
            
             
            </div>
          </div>
        </div>

        {/* VS Badge */}
        <div className="text-[6rem] font-bebas text-yellow-300 relative top-[100px]">VS</div>

        {/* Player 2 */}
        <div className="flex flex-col items-center mt-[100px]">
          <div
            style={{
              background: `linear-gradient(135deg, ${tournament.primaryColor || '#000'}, ${tournament.secondaryColor || '#333'})`,
            }}
            className="w-[600px] h-[505px] p-8 flex flex-col items-center justify-center "
          >
            <img
              src={second.picUrl || '/def_char.avif'}
              alt={second.playerName}
              className="w-[300px] h-[300px] object-cover  top-[100px] absolute z-0"
            />
            <div className="text-[3rem] font-bebas text-black px-[20px] flex justify-center bg-gradient-to-r from-[#FFD700] via-[#FFA500] to-[#FFD700] z-10">
              {second.playerName}
            </div>

             <div className=" w-[600px] text-center bg-[#000000b8] h-[200px] pt-[30px] top-[400px] absolute flex items-center justify-between px-[120px]">
              <div className='w-[100%] text-center'>
                <div className="text-[8rem] font-[AGENCYB] text-yellow-300 ">{second.killNum} KILLS</div>
                
              </div>
            
             
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlayerH2H;
